//
// Created by stani on 08.03.2024.
//
#include "stdio.h"
void showMessage(){
    printf("Brand new string");
}
